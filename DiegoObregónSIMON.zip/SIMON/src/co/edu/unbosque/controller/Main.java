package co.edu.unbosque.controller;

import javax.swing.JOptionPane;

import co.edu.unbosque.view.VentanaJFrame;
import co.edu.unbosque.view.VentanaJPanel;

public class Main {
	public static void main(String[] args) {
		VentanaJPanel jpanel = new VentanaJPanel();
		VentanaJFrame jframe = new VentanaJFrame(jpanel);
		Controlador principal = new Controlador(jframe);
	}

}

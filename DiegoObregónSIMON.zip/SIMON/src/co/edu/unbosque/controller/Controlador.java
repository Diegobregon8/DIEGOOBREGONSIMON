package co.edu.unbosque.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import co.edu.unbosque.model.Secuencia;
import co.edu.unbosque.view.VentanaJFrame;
import co.edu.unbosque.view.VentanaJPanel;

public class Controlador implements ActionListener{
	
	private VentanaJFrame ventanajframe;
	private Secuencia secuencia = new Secuencia();
	private ArrayList<Integer> respuesta = new ArrayList();
	
	public Controlador(VentanaJFrame ventanajframe) {
		this.ventanajframe = ventanajframe;
		ventanajframe.setVisible(true);
		this.ventanajframe.getVentanajpanel().getUnoButton().addActionListener(this);
		this.ventanajframe.getVentanajpanel().getDosButton().addActionListener(this);
		this.ventanajframe.getVentanajpanel().getTresButton().addActionListener(this);
		this.ventanajframe.getVentanajpanel().getCuatroButton().addActionListener(this);
		this.ventanajframe.getVentanajpanel().getTerminarJButton().addActionListener(this);
		respuesta = secuencia.generarSecuencia();
		ventanajframe.getVentanajpanel().cargarSecuencia(respuesta);		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == ventanajframe.getVentanajpanel().getUnoButton()) {
			boolean confirmar = ventanajframe.getVentanajpanel().añadirRespuestas(1);
			if(confirmar == false) {
				JOptionPane.showMessageDialog(null, "Solo puede oprimir 4 botones por turno");
			}
		}
		if (e.getSource() == ventanajframe.getVentanajpanel().getDosButton()) {
			boolean confirmar = ventanajframe.getVentanajpanel().añadirRespuestas(2);
			if(confirmar == false) {
				JOptionPane.showMessageDialog(null, "Solo puede oprimir 4 botones por turno");
			}
		}
		if (e.getSource() == ventanajframe.getVentanajpanel().getTresButton()) {
			boolean confirmar = ventanajframe.getVentanajpanel().añadirRespuestas(3);
			if(confirmar == false) {
				JOptionPane.showMessageDialog(null, "Solo puede oprimir 4 botones por turno");
			}
		}
		if (e.getSource() == ventanajframe.getVentanajpanel().getCuatroButton()) {
			boolean confirmar = ventanajframe.getVentanajpanel().añadirRespuestas(4);
			if(confirmar == false) {
				JOptionPane.showMessageDialog(null, "Solo puede oprimir 4 botones por turno");
				
			}
		}
		if (e.getSource() == ventanajframe.getVentanajpanel().getTerminarJButton()) {
			boolean confirmar = secuencia.verificarRespuesta(ventanajframe.getVentanajpanel().getRespuesta());
			if (confirmar==true) {
				JOptionPane.showMessageDialog(null, "Secuencia exitosa!");
				
			}else {
				JOptionPane.showMessageDialog(null, "Fallaste!");
			}
			System.exit(0);
		}	
		
	}

}

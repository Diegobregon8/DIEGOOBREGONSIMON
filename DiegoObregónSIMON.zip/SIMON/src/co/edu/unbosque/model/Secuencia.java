package co.edu.unbosque.model;

import java.util.ArrayList;
import java.util.Iterator;

public class Secuencia {
	private ArrayList<Integer> secuencia = new ArrayList<Integer>();
	
	
	public Secuencia(ArrayList secuencia) {
		this.secuencia = secuencia;
	}
	
	
	public Secuencia() {
	}

	public ArrayList generarSecuencia() {
		for (int i = 0; i < 4; i++) {
			int numero = (int)(Math.random()*4+1);
			secuencia.add(numero);
		}
		return secuencia;
	}
	
	public boolean verificarRespuesta(ArrayList<Integer> respuesta) {
		int aux = 0;
		for (int i = 0; i < respuesta.size(); i++) {
			if (secuencia.get(i)==respuesta.get(i)) {
				aux++;
			}
		}
		if (aux==4) {
			return true;
		}else {
			return false;
		}
	}
	public void limpiarSecuencia() {
		secuencia.clear();
	}
	
	public ArrayList getSecuencia() {
		return secuencia;
	}


	public void setSecuencia(ArrayList secuencia) {
		this.secuencia = secuencia;
	}	
	
}

package co.edu.unbosque.view;

import java.awt.Color;
import java.awt.Font;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;


public class VentanaJPanel extends JPanel {

	private JButton terminarJButton = new JButton("Terminar");
	
	private JLabel unoGenerado = new JLabel("",SwingConstants.CENTER);
	private JLabel dosGenerado = new JLabel("",SwingConstants.CENTER);
	private JLabel tresGenerado = new JLabel("",SwingConstants.CENTER);
	private JLabel cuatroGenerado = new JLabel("",SwingConstants.CENTER);
	
	private JButton unoButton = new JButton("1");
	private JButton dosButton = new JButton("2");
	private JButton tresButton = new JButton("3");
	private JButton cuatroButton = new JButton("4");
	
	private ArrayList<Integer> respuesta = new ArrayList();
	
	
	public VentanaJPanel() {
		setLayout(null);
		
	    JLabel numero = new JLabel("Número");
	    numero.setBounds(20,40,150,40);
	    numero.setFont(new Font("Serif", Font.PLAIN, 25));
	    add(numero);
	    
	    unoGenerado.setBounds(150, 20, 100, 100);
	    unoGenerado.setBorder(BorderFactory.createLineBorder(Color.GRAY, 5));
	    unoGenerado.setFont(new Font("Serif", Font.PLAIN, 30));
	    unoGenerado.setOpaque(true);
	    unoGenerado.setBackground(Color.LIGHT_GRAY);
	    add(unoGenerado);
	    
	    dosGenerado.setBounds(300, 20, 100, 100);
	    dosGenerado.setBorder(BorderFactory.createLineBorder(Color.GRAY, 5));
	    dosGenerado.setFont(new Font("Serif", Font.PLAIN, 30));
	    dosGenerado.setOpaque(true);
	    dosGenerado.setBackground(Color.LIGHT_GRAY);
	    add(dosGenerado);
	    
	    tresGenerado.setBounds(450, 20, 100, 100);
	    tresGenerado.setBorder(BorderFactory.createLineBorder(Color.GRAY, 5));
	    tresGenerado.setFont(new Font("Serif", Font.PLAIN, 30));
	    tresGenerado.setOpaque(true);
	    tresGenerado.setBackground(Color.LIGHT_GRAY);
	    add(tresGenerado);
	    
	    cuatroGenerado.setBounds(600, 20, 100, 100);
	    cuatroGenerado.setBorder(BorderFactory.createLineBorder(Color.GRAY, 5));
	    cuatroGenerado.setFont(new Font("Serif", Font.PLAIN, 30));
	    cuatroGenerado.setOpaque(true);
	    cuatroGenerado.setBackground(Color.LIGHT_GRAY);
	    add(cuatroGenerado);
	    
	    unoButton.setBounds(120, 160, 250, 200);
	    unoButton.setFont(new Font("Serif", Font.PLAIN, 70));
	    unoButton.setBorder(BorderFactory.createLineBorder(Color.ORANGE, 5));
	    unoButton.setOpaque(true);
	    unoButton.setBackground(Color.YELLOW);
	    add(unoButton);
	    
	    dosButton.setBounds(375, 160, 250, 200);
	    dosButton.setFont(new Font("Serif", Font.PLAIN, 70));
	    dosButton.setBorder(BorderFactory.createLineBorder(new Color(0,11,141), 5));
	    dosButton.setOpaque(true);
	    dosButton.setBackground(Color.BLUE);
	    add(dosButton);
	    
	    tresButton.setBounds(120, 365, 250, 200);
	    tresButton.setFont(new Font("Serif", Font.PLAIN, 70));
	    tresButton.setBorder(BorderFactory.createLineBorder(new Color(186,0,0), 5));
	    tresButton.setOpaque(true);
	    tresButton.setBackground(Color.RED);
	    add(tresButton);
	
	    cuatroButton.setBounds(375, 365, 250, 200);
	    cuatroButton.setFont(new Font("Serif", Font.PLAIN, 70));
	    cuatroButton.setBorder(BorderFactory.createLineBorder(new Color(5, 178, 0), 5));
	    cuatroButton.setOpaque(true);
	    cuatroButton.setBackground(Color.GREEN);
	    add(cuatroButton);
	    
	    
	    terminarJButton.setBounds(290, 600, 150, 40);
	    terminarJButton.setFont(new Font("Serif", Font.PLAIN, 15));
	    terminarJButton.setEnabled(false);
	    add(terminarJButton);
	}


	public void cargarSecuencia(ArrayList<Integer> secuencia) {
		//Valores de labels
		unoGenerado.setText(secuencia.get(0)+"");
		dosGenerado.setText(secuencia.get(1)+"");
		tresGenerado.setText(secuencia.get(2)+"");
		cuatroGenerado.setText(secuencia.get(3)+"");
		//Colores de label 1
		if(secuencia.get(0)==1) {
			unoGenerado.setBorder(BorderFactory.createLineBorder(Color.ORANGE, 5));
			unoGenerado.setOpaque(true);
			unoGenerado.setBackground(Color.YELLOW);
		}else if(secuencia.get(0)==2){
			unoGenerado.setBorder(BorderFactory.createLineBorder(new Color(0,11,141), 5));
			unoGenerado.setOpaque(true);
			unoGenerado.setBackground(Color.BLUE);
		}else if(secuencia.get(0)==3){
			unoGenerado.setBorder(BorderFactory.createLineBorder(new Color(186,0,0), 5));
			unoGenerado.setOpaque(true);
			unoGenerado.setBackground(Color.RED);
		}else if(secuencia.get(0)==4){
			unoGenerado.setBorder(BorderFactory.createLineBorder(new Color(5, 178, 0), 5));
			unoGenerado.setOpaque(true);
			unoGenerado.setBackground(Color.GREEN);
		}
		//Colores de label 2
		if(secuencia.get(1)==1) {
			dosGenerado.setBorder(BorderFactory.createLineBorder(Color.ORANGE, 5));
			dosGenerado.setOpaque(true);
			dosGenerado.setBackground(Color.YELLOW);
		}else if(secuencia.get(1)==2){
			dosGenerado.setBorder(BorderFactory.createLineBorder(new Color(0,11,141), 5));
			dosGenerado.setOpaque(true);
			dosGenerado.setBackground(Color.BLUE);
		}else if(secuencia.get(1)==3){
			dosGenerado.setBorder(BorderFactory.createLineBorder(new Color(186,0,0), 5));
			dosGenerado.setOpaque(true);
			dosGenerado.setBackground(Color.RED);
		}else if(secuencia.get(1)==4){
			dosGenerado.setBorder(BorderFactory.createLineBorder(new Color(5, 178, 0), 5));
			dosGenerado.setOpaque(true);
			dosGenerado.setBackground(Color.GREEN);
		}
		//Colores de label 3
		if(secuencia.get(2)==1) {
			tresGenerado.setBorder(BorderFactory.createLineBorder(Color.ORANGE, 5));
			tresGenerado.setOpaque(true);
			tresGenerado.setBackground(Color.YELLOW);
		}else if(secuencia.get(2)==2){
			tresGenerado.setBorder(BorderFactory.createLineBorder(new Color(0,11,141), 5));
			tresGenerado.setOpaque(true);
			tresGenerado.setBackground(Color.BLUE);
		}else if(secuencia.get(2)==3){
			tresGenerado.setBorder(BorderFactory.createLineBorder(new Color(186,0,0), 5));
			tresGenerado.setOpaque(true);
			tresGenerado.setBackground(Color.RED);
		}else if(secuencia.get(2)==4){
			tresGenerado.setBorder(BorderFactory.createLineBorder(new Color(5, 178, 0), 5));
			tresGenerado.setOpaque(true);
			tresGenerado.setBackground(Color.GREEN);
		}
		//Colores de label 4
		if(secuencia.get(3)==1) {
			cuatroGenerado.setBorder(BorderFactory.createLineBorder(Color.ORANGE, 5));
			cuatroGenerado.setOpaque(true);
			cuatroGenerado.setBackground(Color.YELLOW);
		}else if(secuencia.get(3)==2){
			cuatroGenerado.setBorder(BorderFactory.createLineBorder(new Color(0,11,141), 5));
			cuatroGenerado.setOpaque(true);
			cuatroGenerado.setBackground(Color.BLUE);
		}else if(secuencia.get(3)==3){
			cuatroGenerado.setBorder(BorderFactory.createLineBorder(new Color(186,0,0), 5));
			cuatroGenerado.setOpaque(true);
			cuatroGenerado.setBackground(Color.RED);
		}else if(secuencia.get(3)==4){
			cuatroGenerado.setBorder(BorderFactory.createLineBorder(new Color(5, 178, 0), 5));
			cuatroGenerado.setOpaque(true);
			cuatroGenerado.setBackground(Color.GREEN);
		}
		
		try {
			//Tiempo de espera de menos de 1 segundo
            Thread.sleep(900);
         } catch (Exception e) {
            System.out.println(e);
         }
		
	    
	    unoGenerado.setBackground(Color.LIGHT_GRAY);
	    dosGenerado.setBackground(Color.LIGHT_GRAY);
	    tresGenerado.setBackground(Color.LIGHT_GRAY);
	    cuatroGenerado.setBackground(Color.LIGHT_GRAY);
	    unoGenerado.setBorder(BorderFactory.createLineBorder(Color.GRAY, 5));
	    dosGenerado.setBorder(BorderFactory.createLineBorder(Color.GRAY, 5));
	    tresGenerado.setBorder(BorderFactory.createLineBorder(Color.GRAY, 5));
	    cuatroGenerado.setBorder(BorderFactory.createLineBorder(Color.GRAY, 5));
	    unoGenerado.setText("");
	    dosGenerado.setText("");
	    tresGenerado.setText("");
	    cuatroGenerado.setText("");
	    
	}
	
	public boolean añadirRespuestas(int numero) {
		if(respuesta.size()>3) {
			return false;
		}else {
			if (respuesta.size()==3) {
				terminarJButton.setEnabled(true);
			}
			respuesta.add(numero);
			return true;
		}
		
	}
	
	
	public void limpiarRespuesta() {
		terminarJButton.setEnabled(false);
		respuesta.clear();
	}
	
	public JButton getTerminarJButton() {
		return terminarJButton;
	}

	public void setTerminarJButton(JButton terminarJButton) {
		this.terminarJButton = terminarJButton;
	}


	public JLabel getUnoGenerado() {
		return unoGenerado;
	}


	public void setUnoGenerado(JLabel unoGenerado) {
		this.unoGenerado = unoGenerado;
	}


	public JLabel getDosGenerado() {
		return dosGenerado;
	}


	public void setDosGenerado(JLabel dosGenerado) {
		this.dosGenerado = dosGenerado;
	}


	public JLabel getTresGenerado() {
		return tresGenerado;
	}


	public void setTresGenerado(JLabel tresGenerado) {
		this.tresGenerado = tresGenerado;
	}


	public JLabel getCuatroGenerado() {
		return cuatroGenerado;
	}


	public void setCuatroGenerado(JLabel cuatroGenerado) {
		this.cuatroGenerado = cuatroGenerado;
	}


	public JButton getUnoButton() {
		return unoButton;
	}


	public void setUnoButton(JButton unoButton) {
		this.unoButton = unoButton;
	}


	public JButton getDosButton() {
		return dosButton;
	}


	public void setDosButton(JButton dosButton) {
		this.dosButton = dosButton;
	}


	public JButton getTresButton() {
		return tresButton;
	}


	public void setTresButton(JButton tresButton) {
		this.tresButton = tresButton;
	}


	public JButton getCuatroButton() {
		return cuatroButton;
	}


	public void setCuatroButton(JButton cuatroButton) {
		this.cuatroButton = cuatroButton;
	}


	public ArrayList<Integer> getRespuesta() {
		return respuesta;
	}


	public void setRespuesta(ArrayList<Integer> respuesta) {
		this.respuesta = respuesta;
	}	
	
	
	
}